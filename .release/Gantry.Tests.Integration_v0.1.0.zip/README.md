﻿# Gantry - Integration Tests
*by Gantry*

Welcome to my mod. It does X, Y, and Z.

## Features

These are the basic features of the mod.

### ***Feature 1***

A basic description of the feature.

 - **New Block:** My amazing block.
 - **New Block:** My other amazing block.

### ***Feature 2***

A basic description of the feature.

 - **New Creature:** Something with a terrible loot table.
 - Creature will hunt in packs.
 - Creature is hostile to players.

## Credits

Within this section, you should give credit to any contributors, translators, artists, etc. that have helped to make the mod with you.

## Links

Give links to your GitHub repositories, your social media pages, or anywhere else you'd like people to follow and support your work.