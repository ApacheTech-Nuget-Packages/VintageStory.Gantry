﻿Mod created using Vintage Story Mod Template (.NET Framework), by Apache.
 - Download: https://marketplace.visualstudio.com/items?itemName=ApacheTechSolutions.vsmodtemplate
 - Support: https://bit.ly/aPGDonate